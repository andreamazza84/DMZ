<template>
  <base-section
    id="blog-asset"
    space="2"
    class="px-3"
  >
    <v-img
      :src="require('@/assets/federico-respini-sYffw0LNr7s-unsplash.jpg')"
      height="500px"
      fill
      min-height="400px"
    />
  </base-section>
</template>

<script>
  export default {
    name: 'SectionBlogAsset',
  }
</script>

<style lang="scss" scoped>

</style>
