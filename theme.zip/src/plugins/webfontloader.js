import WebFontLoader from 'webfontloader'

// async load fonts
WebFontLoader.load({
  google: {
    families: [
      'Open+Sans:100,300,400,500,700,900&display=swap',
      'Lato:100,300,400,500,700,900&display=swap',
    ],
  },
})
